# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from knack.help_files import helps  # noqa: F401

# pylint: disable=line-too-long

# add help for intermediate nodes e.g.
# helps['ml'] = """
#             type: group
#             short-summary: Module to access Machine Learning commands
#             """

helps["ml model package-functions"] = """
                  type: command
                  short-summary: PREVIEW Package a model in the workspace to deploy to Azure Functions."""

helps["ml model deploy-iot"] = """
                  type: command
                  short-summary: PREVIEW Deploy a model for IOT."""
