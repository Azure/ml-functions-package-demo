# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from azureml._cli_common.cli_exception_handler import _handle_exceptions

from azureml._cli_common.transformers import transform_image_show
from azureml._cli_common.transformers import table_transform_image_show
from azureml._cli_common.transformers import transform_service_show
from azureml._cli_common.transformers import table_transform_service_show
from azureml._cli_common.transformers import transform_compute_target_show
from azureml._cli_common.transformers import table_transform_compute_target_show
from azureml._cli_common.transformers import transform_mlc_resource_list
from azureml._cli_common.transformers import table_transform_mlc_resource_list
from azureml._cli_common.transformers import transform_mlc_delete
from azureml._cli_common.transformers import table_transform_mlc_delete
from azureml._cli_common.transformers import transform_service_list
from azureml._cli_common.transformers import table_transform_service_list
from azureml._cli_common.transformers import transform_service_delete
from azureml._cli_common.transformers import table_transform_service_delete
from azureml._cli_common.transformers import transform_service_run
from azureml._cli_common.transformers import table_transform_service_run
from azureml._cli_common.transformers import transform_package
from azureml._cli_common.transformers import table_transform_package

# Every command has several parts:
#
# 1. Commands [Add your command to PREVIEW_COMMANDS so that it gets added. Optional arguments for
# registration (such as table_transformer) that must be provided to "cli_command" should be
# included as part of the dictionary in PREVIEW_COMMANDS. Otherwise, add an empty dictionary.]
#
# 2. Command Information [Create a new key for your command in command_details.json.
# This will contain its name, the command itself, the command function/pointer, and arguments.]
#
# 3. Arguments [Should be added as part of the preview_command_details.json file. See other commands for examples.]
#
# 4. Module [Functions called by the commands, make sure to specify their name when
# creating the command.]
#
# 5. Help [Warning: Help is not in this file! Make sure to update _help.py,
# which is under the same directory, with the new commands.]


PREVIEW_COMMANDS = {
    # IoT Contrib Commands
    "ml image create iot-container": {"exception_handler": _handle_exceptions,
                                      "transform": transform_image_show,
                                      "table_transformer": table_transform_image_show},

    "ml model deploy-iot": {"exception_handler": _handle_exceptions,
                            "transform": transform_service_show,
                            "table_transformer": table_transform_service_show},

    "ml computetarget attach-iot": {"exception_handler": _handle_exceptions,
                                    "transform": transform_compute_target_show,
                                    "table_transformer": table_transform_compute_target_show},

    "ml computetarget list-iot": {"exception_handler": _handle_exceptions,
                                  "transform": transform_mlc_resource_list,
                                  "table_transformer": table_transform_mlc_resource_list},

    "ml computetarget detach-iot": {"exception_handler": _handle_exceptions,
                                    "transform": transform_mlc_delete,
                                    "table_transformer": transform_mlc_delete},

    "ml service list-iot": {"exception_handler": _handle_exceptions,
                            "transform": transform_service_list,
                            "table_transformer": table_transform_service_list},

    # package command
    "ml model package-functions": {"exception_handler": _handle_exceptions,
                                   "transform": transform_package,
                                   "table_transformer": table_transform_package}

}
