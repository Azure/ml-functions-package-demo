# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

# Disabling unused-import because "from . import _help" is an unused import,
# but we need this import for our help messages.

import os

from . import _help
from .commands import PREVIEW_COMMANDS
from azureml._cli_common.commands_utility import load_commands
from azureml._cli_common.all_parameters import register_command_arguments
from azureml._base_sdk_common import __version__ as VERSION
import azureml._base_sdk_common.user_agent as user_agent

from azure.cli.core import AzCommandsLoader

preview_command_json_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'preview_command_details.json')


class MachineLearningPreviewCommandsLoader(AzCommandsLoader):
    """
    The machine learning (preview) commands loader.

    References for writing this code are:
    https://github.com/Azure/azure-cli/tree/master/src/command_modules/azure-cli-acr/azure/cli/command_modules/acr
    and
    https://github.com/Microsoft/knack
    """

    def __init__(self, cli_ctx=None):
        super(MachineLearningPreviewCommandsLoader, self).__init__(cli_ctx=cli_ctx)

    def load_command_table(self, args):
        """
        This function is called by az CLI to load commands for the machinelearning preview extension.
        The loaded commands are returned in a dict.
        :param args:
        :return: The command table.
        :rtype dict:
        """

        load_commands(self, PREVIEW_COMMANDS, preview_command_json_file)

        return self.command_table

    def load_arguments(self, command):
        """
        This function is called by az CLI for loading arguments of the currently
        issued CLI command.
        For a command, az CLI first calls load_command_table function, and then
        calls load_arguments function.

        This function only registers arguments for the currently issued command.
        Unlike the code inside core az CLI modules that register arguments for all
        the commands.
        Therefore, this improves the performance.
        :param command: The currently issued command.
        :type command: str
        :return: None
        """
        register_command_arguments(self, command, preview_command_json_file)


COMMAND_LOADER_CLS = MachineLearningPreviewCommandsLoader

__version__ = VERSION

user_agent.append("azureml-cli-preview", __version__)
