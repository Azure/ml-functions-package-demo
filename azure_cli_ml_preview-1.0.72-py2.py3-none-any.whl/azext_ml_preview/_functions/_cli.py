# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from azureml._cli_common.ml_cli_error import MlCliError
from azext_ml._util import create_inference_config, cli_context, collect_input_models, parse_options
import json
from azureml.contrib.functions._package import __package_call


def package_model(models, model_metadata_files, inference_config_file, entry_script, environment_name,
                  environment_version, environment_directory, runtime, conda_file, source_directory,
                  package_option_text, package_options_file, output_path, path, workspace_name, resource_group,
                  verbose_local, no_wait_flag, context=cli_context):
    if (no_wait_flag and output_path):
        raise MlCliError("Error, can't write context to output directory if --no-wait is passed.")

    if (not models) and (not model_metadata_files):
        raise MlCliError('Error, need to specify either --model or --model-metadata-file '
                         'for model(s) to be deployed.')

    workspace = context.get_workspace(workspace_name, resource_group, path)

    # Collect all of the input models. Models can be specified via --model, or --model-metadata-file parameters.
    # In either case, the models need to be registered to MMS first
    registered_models = collect_input_models(workspace, model_metadata_files, models)

    inference_config = create_inference_config(workspace, inference_config_file, entry_script,
                                               environment_name, environment_version,
                                               environment_directory, runtime, conda_file, None, source_directory,
                                               None, None, None, None, None)

    package_options_merged = {}

    package_options = parse_options(package_option_text, "package_options")

    if package_options_file:
        with open(package_options_file, 'r') as file:
            package_options_merged = json.load(file)

    if package_options is not None:
        package_options_merged.update(package_options)

    package = __package_call(workspace, registered_models, inference_config, output_path is not None,
                             package_options_merged)

    if not no_wait_flag:
        package.wait_for_creation(verbose_local)

        if output_path:
            package.save(output_path)

    return package.serialize(), verbose_local
